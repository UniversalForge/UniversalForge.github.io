#include <jni.h>

#ifndef _Included_TestJNI
#define _Included_TestJNI
#ifdef __cplusplus
extern "C" {
#endif

JNIEXPORT jint JNICALL Java_com_uniforge_origin_test_Test_add(JNIEnv *, jobject, jint, jint);

#ifdef __cplusplus
}
#endif
#endif